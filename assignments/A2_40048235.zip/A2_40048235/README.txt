COMP 5421 - Assignment 2

Yishi Wang
40048235

Program are able to be compiled and run at HB-lab-813 through terminal by issuing the following command

Use `g++ *.cpp` to compile the program
Use `./a.out FILENAME` to run it. NOTE: FILENAME is optional

No extra feature implemented.

No known bugs detected.


