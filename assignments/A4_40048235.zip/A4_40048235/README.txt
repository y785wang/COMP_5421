COMP 5421 - Assignment 4

Yishi Wang
40048235

Program is able to be compiled and run at HB-lab through Linux terminal by issuing the following command
Use `g++ -std=c++11 *.cpp` to compile the program
Use `./a.out` to run it

Program is able to be compiled and run at HB-lab through Win7 vs2013 by issuing the following command on vs2013 menu
FILE -> NEW -> Project From Existing Code...
Select Visual C++
    -> Click Next
Enter Project file location and Project name
    -> Click Next
Select Use Visual Studio
    Select Project type as Console application project
    -> Finish
Run with Local Windows Debugger
Note, to see the full result on console, may need add system("PAUSE") somewhere.


No extra feature implemented

No known bugs detected




