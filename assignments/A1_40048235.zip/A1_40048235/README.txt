COMP 5421 - Assignment 1

Yishi Wang
40048235

Use `g++ *.cpp` to build the program
Use `./a.out` to run it

No extra feature implemented.

No known bugs detected.


